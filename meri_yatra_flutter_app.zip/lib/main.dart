import 'package:flutter/material.dart';

void main() => runApp(MeriYatraApp());

class MeriYatraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meri Yatra',
      theme: ThemeData(primarySwatch: Colors.indigo),
      home: LoginScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class LoginScreen extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Welcome to Meri Yatra", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            SizedBox(height: 20),
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: 'Enter Your Name'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => HomeScreen(userName: nameController.text)),
                );
              },
              child: Text("Continue"),
            )
          ],
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  final String userName;
  HomeScreen({required this.userName});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, String>> trips = [];

  final driverController = TextEditingController();
  final locationController = TextEditingController();
  final paymentController = TextEditingController();
  final noteController = TextEditingController();

  void addTrip() {
    setState(() {
      trips.add({
        'driver': driverController.text,
        'location': locationController.text,
        'payment': paymentController.text,
        'note': noteController.text,
        'date': DateTime.now().toString().split(".")[0],
      });
      driverController.clear();
      locationController.clear();
      paymentController.clear();
      noteController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Welcome, ${widget.userName}')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(controller: driverController, decoration: InputDecoration(labelText: 'Driver Name')),
            TextField(controller: locationController, decoration: InputDecoration(labelText: 'Location')),
            TextField(controller: paymentController, decoration: InputDecoration(labelText: 'Payment (₹)')),
            TextField(controller: noteController, decoration: InputDecoration(labelText: 'Notes')),
            SizedBox(height: 10),
            ElevatedButton(onPressed: addTrip, child: Text('Save Trip')),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: trips.length,
                itemBuilder: (context, index) {
                  final trip = trips[index];
                  return Card(
                    child: ListTile(
                      title: Text('${trip['location']} with ${trip['driver']}'),
                      subtitle: Text('₹${trip['payment']} | ${trip['date']}
${trip['note']}'),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
